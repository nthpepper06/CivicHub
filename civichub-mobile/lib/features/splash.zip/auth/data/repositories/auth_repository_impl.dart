import '../../../../core/network/api_exception.dart';
import '../../../../core/storage/auth_token_storage.dart';
import '../../data/models/login_request.dart';
import '../../domain/models/auth_session.dart';
import '../../domain/models/citizen_profile.dart';
import '../../domain/repositories/auth_repository.dart';
import '../datasources/auth_remote_data_source.dart';

class AuthRepositoryImpl implements AuthRepository {
  AuthRepositoryImpl({
    required AuthRemoteDataSource remoteDataSource,
    required AuthTokenStorage tokenStorage,
  }) : _remoteDataSource = remoteDataSource,
       _tokenStorage = tokenStorage;

  final AuthRemoteDataSource _remoteDataSource;
  final AuthTokenStorage _tokenStorage;

  @override
  Future<AuthSession> login(LoginRequest request) async {
    final response = await _remoteDataSource.login(request);
    await _tokenStorage.saveAccessToken(response.accessToken);
    return response.toSession();
  }

  @override
  Future<CitizenProfile?> bootstrapSession() async {
    if (!await _tokenStorage.hasAccessToken()) {
      return null;
    }

    try {
      return await _remoteDataSource.getCurrentUser();
    } on ApiException catch (error) {
      if (error.kind == ApiErrorKind.unauthorized ||
          error.kind == ApiErrorKind.forbidden) {
        await _tokenStorage.deleteAccessToken();
        return null;
      }
      rethrow;
    }
  }

  @override
  Future<CitizenProfile> getCurrentUser() async {
    try {
      return await _remoteDataSource.getCurrentUser();
    } on ApiException catch (error) {
      if (error.kind == ApiErrorKind.unauthorized ||
          error.kind == ApiErrorKind.forbidden) {
        await _tokenStorage.deleteAccessToken();
      }
      rethrow;
    }
  }

  @override
  Future<void> logout() async {
    await _tokenStorage.deleteAccessToken();
  }

  @override
  Future<bool> hasStoredToken() {
    return _tokenStorage.hasAccessToken();
  }
}
