import 'package:dio/dio.dart';

import '../../../../core/network/api_client.dart';
import '../../../../core/network/api_endpoints.dart';
import '../models/login_request.dart';
import '../models/login_response.dart';
import '../../domain/models/auth_enums.dart';
import '../../domain/models/citizen_profile.dart';

abstract class AuthRemoteDataSource {
  Future<LoginResponse> login(LoginRequest request);
  Future<CitizenProfile> getCurrentUser();
}

class AuthRemoteDataSourceImpl implements AuthRemoteDataSource {
  AuthRemoteDataSourceImpl({required ApiClient apiClient})
    : _apiClient = apiClient;

  final ApiClient _apiClient;

  @override
  Future<LoginResponse> login(LoginRequest request) async {
    try {
      final response = await _apiClient.dio.post<Map<String, dynamic>>(
        ApiEndpoints.authLogin,
        data: request.toJson(),
      );
      final data = response.data?['data'] as Map<String, dynamic>? ?? const {};
      return LoginResponse.fromJson(data);
    } on DioException catch (error) {
      throw _apiClient.mapDioError(error);
    }
  }

  @override
  Future<CitizenProfile> getCurrentUser() async {
    try {
      final response = await _apiClient.dio.get<Map<String, dynamic>>(
        ApiEndpoints.authMe,
      );
      final data = response.data?['data'] as Map<String, dynamic>? ?? const {};
      return _toCitizenProfile(data);
    } on DioException catch (error) {
      throw _apiClient.mapDioError(error);
    }
  }

  CitizenProfile _toCitizenProfile(Map<String, dynamic> json) {
    return CitizenProfile(
      id: (json['id'] as num?)?.toInt(),
      fullName: json['fullName'] as String? ?? '',
      email: json['email'] as String? ?? '',
      phone: json['phone'] as String?,
      avatar: json['avatar'] as String?,
      role: userRoleFromJson(json['role'] as String?),
      status: userStatusFromJson(json['status'] as String?),
      isActive: json['isActive'] as bool? ?? false,
      departmentId: (json['departmentId'] as num?)?.toInt(),
      departmentName: json['departmentName'] as String?,
    );
  }
}
