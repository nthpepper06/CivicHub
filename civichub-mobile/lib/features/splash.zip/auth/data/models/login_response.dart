import '../../domain/models/auth_enums.dart';
import '../../domain/models/auth_session.dart';
import '../../domain/models/citizen_profile.dart';

class LoginResponse {
  const LoginResponse({
    required this.accessToken,
    required this.tokenType,
    required this.expiresIn,
    required this.user,
  });

  final String accessToken;
  final String tokenType;
  final int expiresIn;
  final CitizenProfile user;

  factory LoginResponse.fromJson(Map<String, dynamic> json) {
    final userJson = json['user'] as Map<String, dynamic>? ?? const {};
    return LoginResponse(
      accessToken: json['accessToken'] as String? ?? '',
      tokenType: json['tokenType'] as String? ?? 'Bearer',
      expiresIn: (json['expiresIn'] as num?)?.toInt() ?? 0,
      user: CitizenProfile(
        id: (userJson['id'] as num?)?.toInt(),
        fullName: userJson['fullName'] as String? ?? '',
        email: userJson['email'] as String? ?? '',
        phone: userJson['phone'] as String?,
        avatar: userJson['avatar'] as String?,
        role: userRoleFromJson(userJson['role'] as String?),
        status: userStatusFromJson(userJson['status'] as String?),
        isActive: userJson['isActive'] as bool? ?? false,
        departmentId: (userJson['departmentId'] as num?)?.toInt(),
        departmentName: userJson['departmentName'] as String?,
      ),
    );
  }

  AuthSession toSession() {
    return AuthSession(
      accessToken: accessToken,
      tokenType: tokenType,
      expiresIn: expiresIn,
      user: user,
    );
  }
}
