import 'package:equatable/equatable.dart';

import '../../domain/models/citizen_profile.dart';

enum AuthStatus { unknown, checking, authenticated, unauthenticated }

class AuthState extends Equatable {
  const AuthState({required this.status, this.user});

  const AuthState.unknown() : this(status: AuthStatus.unknown);
  const AuthState.checking() : this(status: AuthStatus.checking);
  const AuthState.authenticated(CitizenProfile user)
    : this(status: AuthStatus.authenticated, user: user);
  const AuthState.unauthenticated() : this(status: AuthStatus.unauthenticated);

  final AuthStatus status;
  final CitizenProfile? user;

  bool get isAuthenticated =>
      status == AuthStatus.authenticated && user != null;
  bool get isLoading => status == AuthStatus.checking;

  AuthState copyWith({AuthStatus? status, CitizenProfile? user}) {
    return AuthState(status: status ?? this.status, user: user ?? this.user);
  }

  @override
  List<Object?> get props => [status, user];
}
