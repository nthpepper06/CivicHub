enum UserRole { citizen, staff, admin }

enum UserStatus { active, inactive, blocked }

UserRole userRoleFromJson(String? value) {
  return switch (value?.toUpperCase()) {
    'STAFF' => UserRole.staff,
    'ADMIN' => UserRole.admin,
    _ => UserRole.citizen,
  };
}

UserStatus userStatusFromJson(String? value) {
  return switch (value?.toUpperCase()) {
    'INACTIVE' => UserStatus.inactive,
    'BLOCKED' => UserStatus.blocked,
    _ => UserStatus.active,
  };
}

String userRoleToJson(UserRole role) {
  return switch (role) {
    UserRole.citizen => 'CITIZEN',
    UserRole.staff => 'STAFF',
    UserRole.admin => 'ADMIN',
  };
}

String userStatusToJson(UserStatus status) {
  return switch (status) {
    UserStatus.active => 'ACTIVE',
    UserStatus.inactive => 'INACTIVE',
    UserStatus.blocked => 'BLOCKED',
  };
}
