class ApiEndpoints {
  static const authLogin = '/api/auth/login';
  static const authMe = '/api/auth/me';
}
