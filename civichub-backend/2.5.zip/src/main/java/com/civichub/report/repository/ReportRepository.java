package com.civichub.report.repository;

import com.civichub.report.entity.Report;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface ReportRepository extends JpaRepository<Report, Long>, JpaSpecificationExecutor<Report> {

    Optional<Report> findByIdAndUserId(Long reportId, Long userId);

    Optional<Report> findByIdAndDepartmentId(Long reportId, Long departmentId);
}
